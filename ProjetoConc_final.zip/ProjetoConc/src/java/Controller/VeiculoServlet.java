package Controller;

import DAO.VeiculoDAO;
import Model.Veiculo;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet(name = "VeiculoServlet", urlPatterns = {"/VeiculoServlet"})
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB
    maxRequestSize = 1024 * 1024 * 50     // 50MB
)
public class VeiculoServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");

        // Recolher os campos vindos do formulário HTML
        String placa = request.getParameter("placa");
        String marca = request.getParameter("marca");
        String modelo = request.getParameter("modelo");
        String cor = request.getParameter("cor");
        String categoria = request.getParameter("categoria");
        
        int ano = 0;
        double quilometragem = 0.0;
        double preco = 0.0;

        try {
            if (request.getParameter("ano") != null) {
                ano = Integer.parseInt(request.getParameter("ano"));
            }
            if (request.getParameter("quilometragem") != null) {
                quilometragem = Double.parseDouble(request.getParameter("quilometragem"));
            }
            if (request.getParameter("preco") != null) {
                preco = Double.parseDouble(request.getParameter("preco"));
            }
        } catch (NumberFormatException e) {
            System.out.println("Erro na conversão numérica: " + e.getMessage());
        }
         // Processamento do upload da foto do veículo (Corrigido para "foto")
String nomeArquivo = "";
String diagnosticoUpload; // só para depuração visível na tela
try {
    Part filePart = request.getPart("imagem");
    if (filePart == null) {
        diagnosticoUpload = "O campo 'foto' não chegou na requisição (filePart é null).";
    } else if (filePart.getSize() <= 0) {
        diagnosticoUpload = "O campo 'foto' chegou, mas está vazio (0 bytes). "
                + "Provavelmente nenhum arquivo foi selecionado no formulário.";
    } else {
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

        String uploadPath = "C:" + File.separator + "ImagensCarros";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }

        filePart.write(uploadPath + File.separator + fileName);
        nomeArquivo = fileName;
        diagnosticoUpload = "Upload OK: " + filePart.getSize() + " bytes salvos em "
                + uploadPath + File.separator + fileName;
    }
} catch (Exception e) {
    diagnosticoUpload = "ERRO ao processar upload: " + e.getClass().getName() + " - " + e.getMessage();
    e.printStackTrace();
}
       
        // Criar e preencher o objeto Veiculo
        Veiculo veiculo = new Veiculo();
        veiculo.setPlaca(placa);
        veiculo.setAno(ano);
        veiculo.setMarca(marca);
        veiculo.setModelo(modelo);
        veiculo.setCor(cor);
        veiculo.setQuilometragem(quilometragem);
        veiculo.setPreco(preco);
        veiculo.setCategoria(categoria);
        veiculo.setImagem(nomeArquivo); 

        // Salvar utilizando o DAO
        VeiculoDAO dao = new VeiculoDAO();
        boolean sucesso = dao.salvar(veiculo);

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Cadastro - Quiet and Fast Luxury</title>");
            out.println("</head>");
            out.println("<body style='background: #15151a; color: #ede7da; font-family: sans-serif; text-align: center; padding-top: 60px;'>");
            if (sucesso) {
                out.println("<h1 style='color: #b08a55;'>Veículo cadastrado com sucesso!</h1>");
                out.println("<p>O superdesportivo foi registado na base de dados.</p>");
            } else {
                out.println("<h1 style='color: #c0605a;'>Erro ao cadastrar veículo.</h1>");
                out.println("<p>Verifique se os dados estão corretos ou se a placa já se encontra registada.</p>");
            }
            out.println("<p style='color:#888; font-size:0.85em;'>[debug] " + diagnosticoUpload + "</p>");
            out.println("<br><br><a href='cadastrar_Veiculo.html' style='color: #b08a55; text-decoration: none;'>← Registar outro veículo</a> | ");
            out.println("<a href='catalogo.jsp' style='color: #b08a55; text-decoration: none;'>Ver Catálogo de Luxo →</a>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet para processamento de cadastro de veículos";
    }
}