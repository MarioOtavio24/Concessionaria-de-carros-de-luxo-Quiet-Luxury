package Controller;

import DAO.VendedorDAO;
import Model.Vendedor;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "VendedorServlet", urlPatterns = {"/VendedorServlet"})
public class VendedorServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");

        String nome = request.getParameter("nome");
        String cpf = request.getParameter("cpf");
        String telefone = request.getParameter("telefone");
        String email = request.getParameter("email");

        double comissao = 0.0;
        try {
            if (request.getParameter("comissao") != null) {
                // O formulário pede a comissão em porcentagem (ex: 5 para 5%),
                // guardamos como fração (0.05) no banco.
                comissao = Double.parseDouble(request.getParameter("comissao")) / 100.0;
            }
        } catch (NumberFormatException e) {
            System.out.println("Erro na conversão da comissão: " + e.getMessage());
        }

        Vendedor vendedor = new Vendedor();
        vendedor.setNome(nome);
        vendedor.setCpf(cpf);
        vendedor.setTelefone(telefone);
        vendedor.setEmail(email);
        vendedor.setComissão(comissao);

        VendedorDAO dao = new VendedorDAO();
        boolean sucesso = dao.cadastrar(vendedor);

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head><title>Cadastro de Vendedor - Mario & Guilherme Luxury Cars</title></head>");
            out.println("<body style='background: #15151a; color: #ede7da; font-family: sans-serif; text-align: center; padding-top: 60px;'>");
            if (sucesso) {
                out.println("<h1 style='color: #b08a55;'>Vendedor cadastrado com sucesso!</h1>");
            } else {
                out.println("<h1 style='color: #c0605a;'>Erro ao cadastrar vendedor.</h1>");
                out.println("<p>Verifique se o CPF, telefone ou e-mail já não estão em uso.</p>");
            }
            out.println("<br><a href='cadastrar_Vendedor.html' style='color: #b08a55; text-decoration: none;'>&larr; Cadastrar outro vendedor</a> | ");
            out.println("<a href='catalogo.jsp' style='color: #b08a55; text-decoration: none;'>Ver Catálogo de Luxo &rarr;</a>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
