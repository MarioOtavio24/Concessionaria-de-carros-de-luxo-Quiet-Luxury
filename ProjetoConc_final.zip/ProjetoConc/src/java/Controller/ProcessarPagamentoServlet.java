package Controller;

import DAO.ClienteDAO;
import DAO.FormaPagamentoDAO;
import DAO.VeiculoDAO;
import DAO.VendaDAO;
import DAO.VendedorDAO;
import Model.Cliente;
import Model.FormaPagamento;
import Model.Veiculo;
import Model.Venda;
import Model.Vendedor;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "ProcessarPagamentoServlet", urlPatterns = {"/ProcessarPagamentoServlet"})
public class ProcessarPagamentoServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");

        String placa = request.getParameter("placa");
        String metodo = request.getParameter("metodo");
        String nome = request.getParameter("nome");
        String cpf = request.getParameter("cpf");
        String telefone = request.getParameter("telefone");
        String email = request.getParameter("email");
        String endereco = request.getParameter("endereco");

        int parcelas = 1;
        try {
            if (request.getParameter("parcelas") != null && !request.getParameter("parcelas").isEmpty()) {
                parcelas = Integer.parseInt(request.getParameter("parcelas"));
            }
        } catch (NumberFormatException e) {
            parcelas = 1;
        }

        String erro = null;

        // 1) Confirma que o veículo existe e ainda está disponível
        VeiculoDAO veiculoDAO = new VeiculoDAO();
        Veiculo veiculo = (placa != null) ? veiculoDAO.buscarPorPlaca(placa) : null;
        if (veiculo == null) {
            erro = "Veículo não encontrado.";
        }

        // 2) Vendedor responsável (ainda não há login de vendedor no site,
        // então usamos o primeiro vendedor cadastrado)
        Vendedor vendedor = null;
        if (erro == null) {
            VendedorDAO vendedorDAO = new VendedorDAO();
            vendedor = vendedorDAO.buscarPrimeiro();
            if (vendedor == null) {
                erro = "Nenhum vendedor está cadastrado no sistema. Cadastre pelo menos um vendedor antes de vender um veículo.";
            }
        }

        // 3) Cliente: reaproveita se já existe (pelo CPF) ou cadastra um novo
        int idCliente = -1;
        if (erro == null) {
            ClienteDAO clienteDAO = new ClienteDAO();
            Cliente existente = (cpf != null) ? clienteDAO.buscarPorCpf(cpf) : null;

            if (existente != null) {
                idCliente = existente.getIdCliente();
            } else {
                Cliente novoCliente = new Cliente();
                novoCliente.setNome(nome);
                novoCliente.setCpf(cpf);
                novoCliente.setTelefone(telefone);
                novoCliente.setEmail(email);
                novoCliente.setEndereco(endereco);
                idCliente = clienteDAO.cadastrar(novoCliente);
            }

            if (idCliente == -1) {
                erro = "Não foi possível cadastrar os dados do cliente. Verifique se o CPF, telefone e e-mail já não estão em uso.";
            }
        }

        // 4) Registra a venda
        int idVenda = -1;
        if (erro == null) {
            Venda venda = new Venda();
            venda.setIdCliente(idCliente);
            venda.setIdVendedor(vendedor.getIdVendedor());
            venda.setIdVeiculo(veiculo.getIdVeiculo());
            venda.setDataVenda(LocalDate.now());
            venda.setValorTotal(veiculo.getPreco());
            venda.setStatus("Finalizada");

            VendaDAO vendaDAO = new VendaDAO();
            idVenda = vendaDAO.cadastrar(venda);

            if (idVenda == -1) {
                erro = "Não foi possível registrar a venda.";
            }
        }

        // 5) Registra a forma de pagamento
        if (erro == null) {
            FormaPagamento formaPagamento = new FormaPagamento();
            formaPagamento.setIdVenda(idVenda);
            formaPagamento.setTipo(metodo);
            formaPagamento.setParcelas(parcelas);
            formaPagamento.setValor(veiculo.getPreco());

            FormaPagamentoDAO formaPagamentoDAO = new FormaPagamentoDAO();
            boolean sucessoPagamento = formaPagamentoDAO.cadastrar(formaPagamento);

            if (!sucessoPagamento) {
                erro = "A venda foi registrada, mas houve um erro ao salvar a forma de pagamento.";
            }
        }

        // 6) Tira o veículo do catálogo (sai do "estoque")
        if (erro == null) {
            veiculoDAO.atualizarStatus(placa, "vendido");
        }

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head><title>Pagamento - Mario & Guilherme Luxury Cars</title></head>");
            out.println("<body style='background:#15151a; color:#ede7da; font-family: sans-serif; text-align:center; padding-top:60px;'>");

            if (erro == null) {
                out.println("<h1 style='color:#b08a55;'>Compra confirmada!</h1>");
                out.println("<p>O veículo " + veiculo.getMarca() + " " + veiculo.getModelo()
                        + " (placa " + veiculo.getPlaca() + ") foi vendido com sucesso.</p>");
            } else {
                out.println("<h1 style='color:#c0605a;'>Não foi possível concluir a compra</h1>");
                out.println("<p>" + erro + "</p>");
            }

            out.println("<br><a href='catalogo.jsp' style='color:#b08a55; text-decoration:none;'>&larr; Voltar ao Catálogo</a>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("catalogo.jsp");
    }
}