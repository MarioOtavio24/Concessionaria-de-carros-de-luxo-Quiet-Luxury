package DAO;

import Model.FormaPagamento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FormaPagamentoDAO {

    public boolean cadastrar(FormaPagamento obj) {
        String sql = "INSERT INTO formapagamento (id_venda, tipo, parcelas, valor) VALUES (?, ?, ?, ?)";

        try (Connection con = ConexaoBD.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, obj.getIdVenda());
            stmt.setString(2, obj.getTipo());
            stmt.setInt(3, obj.getParcelas());
            stmt.setDouble(4, obj.getValor());

            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar forma de pagamento: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public FormaPagamento consultar(int id) {
        String sql = "SELECT * FROM formapagamento WHERE id = ?";
        FormaPagamento obj = null;

        try (Connection con = ConexaoBD.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    obj = new FormaPagamento();
                    obj.setIdFormaPagamento(rs.getInt("id"));
                    obj.setIdVenda(rs.getInt("id_venda"));
                    obj.setTipo(rs.getString("tipo"));
                    obj.setParcelas(rs.getInt("parcelas"));
                    obj.setValor(rs.getDouble("valor"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro ao consultar forma de pagamento: " + e.getMessage());
        }

        return obj;
    }

    public void atualizar(FormaPagamento obj) {
        String sql = "UPDATE formapagamento SET id_venda = ?, tipo = ?, parcelas = ?, valor = ? WHERE id = ?";

        try (Connection con = ConexaoBD.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, obj.getIdVenda());
            stmt.setString(2, obj.getTipo());
            stmt.setInt(3, obj.getParcelas());
            stmt.setDouble(4, obj.getValor());
            stmt.setInt(5, obj.getIdFormaPagamento());

            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar forma de pagamento: " + e.getMessage());
        }
    }

    public void deletar(int id) {
        String sql = "DELETE FROM formapagamento WHERE id = ?";

        try (Connection con = ConexaoBD.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao deletar forma de pagamento: " + e.getMessage());
        }
    }
}