/*
 * Click nbfs://nbhost/SystemFileSystem/...
 * Click nbfs://nbhost/SystemFileSystem/...
 */
package DAO;

import Model.Estoque;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;




public class EstoqueDAO {

    public void cadastrar(Estoque obj) {
        String sql = "INSERT INTO estoque (quantidade, localizacao, dataEntrada) VALUES (?, ?, ?)";

        try (Connection con = new ConexaoBD().getConexao();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, obj.getQuantidade());
            stmt.setString(2, obj.getLocalização());
            stmt.setDate(3, Date.valueOf(obj.getDataEntrada()));

            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar estoque: " + e.getMessage());
        }
    }

    public Estoque consultar(int id) {
        String sql = "SELECT * FROM estoque WHERE idEstoque = ?";
        Estoque obj = null;

        try (Connection con = new ConexaoBD().getConexao();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                obj = new Estoque();
                obj.setIdEstoque(rs.getInt("idEstoque"));
                obj.setQuantidade(rs.getInt("quantidade"));
                obj.setLocalização(rs.getString("localizacao"));
                obj.setDataEntrada(rs.getDate("dataEntrada").toLocalDate());
            }

        } catch (SQLException e) {
            System.out.println("Erro ao consultar estoque: " + e.getMessage());
        }

        return obj;
    }

    public void atualizar(Estoque obj) {
        String sql = "UPDATE estoque SET quantidade = ?, localizacao = ?, dataEntrada = ? WHERE idEstoque = ?";

        try (Connection con = new ConexaoBD().getConexao();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, obj.getQuantidade());
            stmt.setString(2, obj.getLocalização());
            stmt.setDate(3, Date.valueOf(obj.getDataEntrada()));
            stmt.setInt(4, obj.getIdEstoque());

            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar estoque: " + e.getMessage());
        }
    }

    public void deletar(int id) {
        String sql = "DELETE FROM estoque WHERE idEstoque = ?";

        try (Connection con = new ConexaoBD().getConexao();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao deletar estoque: " + e.getMessage());
        }
    }
}