
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Model.Veiculo;

public class VeiculoDAO {
    // Método salvar esperado pelo Servlet
    public boolean salvar(Veiculo veiculo) {
    String sql = "INSERT INTO veiculo (placa, marca, modelo, ano, cor, preco, quilometragem, categoria, imagem) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    try (Connection conexao = ConexaoBD.getConnection();
         PreparedStatement stmt = conexao.prepareStatement(sql)) {

        stmt.setString(1, veiculo.getPlaca());
        stmt.setString(2, veiculo.getMarca());
        stmt.setString(3, veiculo.getModelo());
        stmt.setInt(4, veiculo.getAno());
        stmt.setString(5, veiculo.getCor());
        stmt.setDouble(6, veiculo.getPreco());
        stmt.setDouble(7, veiculo.getQuilometragem());
        stmt.setString(8, veiculo.getCategoria());
        stmt.setString(9, veiculo.getImagem());

        stmt.executeUpdate();
        System.out.println("SUCESSO: Veículo inserido na base de dados com placa: " + veiculo.getPlaca());
        return true;

    } catch (SQLException e) {
        System.out.println("ERRO SQL AO SALVAR: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}
    public void cadastrar(Veiculo veiculo) {
        String sql = "INSERT INTO veiculo (placa, marca, modelo, ano, cor, preco, quilometragem, categoria,imgaem) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, veiculo.getPlaca());
            stmt.setString(2, veiculo.getMarca());
            stmt.setString(3, veiculo.getModelo());
            stmt.setInt(4, veiculo.getAno());
            stmt.setString(5, veiculo.getCor());
            stmt.setDouble(6, veiculo.getPreco());
            stmt.setDouble(7, veiculo.getQuilometragem());
            stmt.setString(8, veiculo.getCategoria());
            stmt.setString(9, veiculo.getImagem());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
        
    public Veiculo consultar(int idVeiculo) {
        String sql = "SELECT * FROM veiculo WHERE id = ?";
        Veiculo veiculo = null;

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idVeiculo);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    veiculo = montarVeiculo(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return veiculo;
    }

    public List<Veiculo> listarTodos() {
        String sql = "SELECT * FROM veiculo WHERE status = 'disponivel'";
        List<Veiculo> veiculos = new ArrayList<>();

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                veiculos.add(montarVeiculo(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return veiculos;
    }

    // Busca um veículo disponível pela placa (usado na tela de pagamento)
    public Veiculo buscarPorPlaca(String placa) {
        String sql = "SELECT * FROM veiculo WHERE placa = ?";
        Veiculo veiculo = null;

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, placa);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    veiculo = montarVeiculo(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return veiculo;
    }

    // Marca o veículo como vendido para ele sair do catálogo
    public boolean atualizarStatus(String placa, String status) {
        String sql = "UPDATE veiculo SET status = ? WHERE placa = ?";

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, status);
            stmt.setString(2, placa);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void atualizar(Veiculo veiculo) {
        String sql = "UPDATE veiculo SET placa = ?, marca = ?, modelo = ?, ano = ?, cor = ?, "
                + "preco = ?, quilometragem = ?, categoria = ? WHERE id = ?";

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, veiculo.getPlaca());
            stmt.setString(2, veiculo.getMarca());
            stmt.setString(3, veiculo.getModelo());
            stmt.setInt(4, veiculo.getAno());
            stmt.setString(5, veiculo.getCor());
            stmt.setDouble(6, veiculo.getPreco());
            stmt.setDouble(7, veiculo.getQuilometragem());
            stmt.setString(8, veiculo.getCategoria());
            stmt.setInt(9, veiculo.getIdVeiculo());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletar(int idVeiculo) {
        String sql = "DELETE FROM veiculo WHERE id = ?";

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idVeiculo);
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método auxiliar para não repetir a montagem do objeto em consultar() e listarTodos()
    private Veiculo montarVeiculo(ResultSet rs) throws SQLException {
        Veiculo veiculo = new Veiculo();
        veiculo.setIdVeiculo(rs.getInt("id"));
        veiculo.setPlaca(rs.getString("placa"));
        veiculo.setMarca(rs.getString("marca"));
        veiculo.setModelo(rs.getString("modelo"));
        veiculo.setAno(rs.getInt("ano"));
        veiculo.setCor(rs.getString("cor"));
        veiculo.setPreco(rs.getDouble("preco"));
        veiculo.setQuilometragem(rs.getDouble("quilometragem"));
        veiculo.setCategoria(rs.getString("categoria"));
        veiculo.setImagem(rs.getString("imagem"));
        return veiculo;
    }

    public void inserir(Veiculo v) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void remover(int idVeiculo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Object buscarPorId(int idVeiculo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}