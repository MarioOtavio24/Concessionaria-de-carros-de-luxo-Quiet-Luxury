package DAO;

import Model.Venda;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class VendaDAO {

    // Cadastra a venda e devolve o id gerado (necessário para vincular a forma de pagamento).
    // Retorna -1 se falhar.
    public int cadastrar(Venda obj) {
        String sql = "INSERT INTO venda (id_cliente, id_vendedor, id_veiculo, data_venda, valor_total, status) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = ConexaoBD.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, obj.getIdCliente());
            stmt.setInt(2, obj.getIdVendedor());
            stmt.setInt(3, obj.getIdVeiculo());
            stmt.setDate(4, Date.valueOf(obj.getDataVenda()));
            stmt.setDouble(5, obj.getValorTotal());
            stmt.setString(6, obj.getStatus());

            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar venda: " + e.getMessage());
            e.printStackTrace();
        }

        return -1;
    }

    public Venda consultar(int id) {
        String sql = "SELECT * FROM venda WHERE id = ?";
        Venda obj = null;

        try (Connection con = ConexaoBD.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    obj = montarVenda(rs);
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro ao consultar venda: " + e.getMessage());
        }

        return obj;
    }

    public void atualizar(Venda obj) {
        String sql = "UPDATE venda SET id_cliente = ?, id_vendedor = ?, id_veiculo = ?, "
                + "data_venda = ?, valor_total = ?, status = ? WHERE id = ?";

        try (Connection con = ConexaoBD.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, obj.getIdCliente());
            stmt.setInt(2, obj.getIdVendedor());
            stmt.setInt(3, obj.getIdVeiculo());
            stmt.setDate(4, Date.valueOf(obj.getDataVenda()));
            stmt.setDouble(5, obj.getValorTotal());
            stmt.setString(6, obj.getStatus());
            stmt.setInt(7, obj.getIdVenda());

            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar venda: " + e.getMessage());
        }
    }

    public void deletar(int id) {
        String sql = "DELETE FROM venda WHERE id = ?";

        try (Connection con = ConexaoBD.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao deletar venda: " + e.getMessage());
        }
    }

    private Venda montarVenda(ResultSet rs) throws SQLException {
        Venda obj = new Venda();
        obj.setIdVenda(rs.getInt("id"));
        obj.setIdCliente(rs.getInt("id_cliente"));
        obj.setIdVendedor(rs.getInt("id_vendedor"));
        obj.setIdVeiculo(rs.getInt("id_veiculo"));
        obj.setDataVenda(rs.getDate("data_venda").toLocalDate());
        obj.setValorTotal(rs.getDouble("valor_total"));
        obj.setStatus(rs.getString("status"));
        return obj;
    }
}