package Model;

import java.time.LocalDate;
import java.util.List;
import DAO.VeiculoDAO;

public class Estoque {
    private int idEstoque;
    private int quantidade;
    private String localizacao;
    private LocalDate dataEntrada;

    private VeiculoDAO veiculoDAO = new VeiculoDAO();

    // Metodos da classe Estoque

    public void adicionarVeiculo(Veiculo v) {
        veiculoDAO.inserir(v); // ajuste o nome do método conforme sua DAO
        this.quantidade++;
    }

    public void removerVeiculo(Veiculo v) {
        veiculoDAO.remover(v.getIdVeiculo()); // ajuste conforme sua DAO
        if (this.quantidade > 0) {
            this.quantidade--;
        }
    }

    public List<Veiculo> consultarEstoque() {
        return veiculoDAO.listarTodos(); // retorna todos os veículos em estoque
    }

    public boolean verificarDisponibilidade(int idVeiculo) {
        return veiculoDAO.buscarPorId(idVeiculo) != null;
    }

    // getters e setters...
    
    
    public int getIdEstoque() {
    return idEstoque;
}

public void setIdEstoque(int idEstoque) {
    this.idEstoque = idEstoque;
}

public int getQuantidade() {
    return quantidade;
}

public void setQuantidade(int quantidade) {
    if (quantidade < 0) {
        throw new IllegalArgumentException("Quantidade não pode ser negativa");
    }
    this.quantidade = quantidade;
}

public String getLocalização() {
    return localizacao;
}

public void setLocalização(String localização) {
    this.localizacao = localização;
}

public LocalDate getDataEntrada() {
    return dataEntrada;
}

public void setDataEntrada(LocalDate dataEntrada) {
    this.dataEntrada = dataEntrada;
}
    
    
}