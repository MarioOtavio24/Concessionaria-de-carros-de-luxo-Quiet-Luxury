

package Model;

import java.time.LocalDate;

public class Venda {
    private int idVenda;
    private int idCliente;
    private int idVendedor;
    private int idVeiculo;
    private LocalDate dataVenda;
    private double valorTotal;
    private String status;

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getIdVendedor() {
        return idVendedor;
    }

    public void setIdVendedor(int idVendedor) {
        this.idVendedor = idVendedor;
    }

    public int getIdVeiculo() {
        return idVeiculo;
    }

    public void setIdVeiculo(int idVeiculo) {
        this.idVeiculo = idVeiculo;
    }

    // Metodos

    public void registrarVenda() {
        this.dataVenda = LocalDate.now();
        this.status = "Registrada";
        // aqui depois entra a chamada pra VendaDAO.inserir(this), se você criar essa DAO
    }

    public double calcularTotal() {
        // ajuste essa lógica de acordo com como o valor é composto (itens, veículo, descontos etc.)
        return this.valorTotal;
    }

    public void finalizarVenda() {
        this.status = "Finalizada";
    }

    public void cancelarVenda() {
        this.status = "Cancelada";
    }

    // Getters e Setters

    public int getIdVenda() {
        return idVenda;
    }

    public void setIdVenda(int idVenda) {
        this.idVenda = idVenda;
    }

    public LocalDate getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(LocalDate dataVenda) {
        this.dataVenda = dataVenda;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        if (valorTotal < 0) {
            throw new IllegalArgumentException("Valor total não pode ser negativo");
        }
        this.valorTotal = valorTotal;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}