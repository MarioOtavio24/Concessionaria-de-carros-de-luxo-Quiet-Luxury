/*
 * Click nbfs://nbhost/SystemFileSystem/...
 * Click nbfs://nbhost/SystemFileSystem/...
 */
package Model;

/**
 *
 * @author otavi
 */
public class FormaPagamento {
    private int idFormaPagamento;
    private int idVenda;
    private String tipo;
    private int parcelas;
    private double valor;

    public int getIdVenda() {
        return idVenda;
    }

    public void setIdVenda(int idVenda) {
        this.idVenda = idVenda;
    }

    public int getParcelas() {
        return parcelas;
    }

    public void setParcelas(int parcelas) {
        this.parcelas = parcelas;
    }

    // Metodos
   

    public void cadastrar() {
        // aqui depois entra a chamada pra FormaPagamentoDAO.inserir(this)
    }

    public void atualizar() {
        // aqui depois entra a chamada pra FormaPagamentoDAO.atualizar(this)
    }

    public FormaPagamento consultar(int id) {
        // aqui depois entra a chamada pra FormaPagamentoDAO.buscarPorId(id)
        return null;
    }

    public void deletar() {
        // aqui depois entra a chamada pra FormaPagamentoDAO.deletar(this.idFormaPagamento)
    }

    public boolean processarPagamento() {
        // lógica de processamento de acordo com o tipo e as parcelas
        return true;
    }

    // Getters e Setters

    public int getIdFormaPagamento() {
        return idFormaPagamento;
    }

    public void setIdFormaPagamento(int idFormaPagamento) {
        this.idFormaPagamento = idFormaPagamento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        if (valor < 0) {
            throw new IllegalArgumentException("Valor não pode ser negativo");
        }
        this.valor = valor;
    }
}