<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Model.Veiculo" %>
<%@ page import="DAO.VeiculoDAO" %>
<%
    String placa = request.getParameter("id");
    Veiculo veiculoSelecionado = (placa != null) ? new VeiculoDAO().buscarPorPlaca(placa) : null;
%>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamento — Mario & Guilherme Luxury Cars</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Work+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --ink: #15151a;
            --surface: #1f1e24;
            --surface-raised: #262530;
            --brass: #b08a55;
            --brass-soft: rgba(176, 138, 85, 0.35);
            --ivory: #ede7da;
            --muted: #96907f;
            --hairline: #322f36;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background: var(--ink);
            color: var(--ivory);
            font-family: 'Work Sans', sans-serif;
            min-height: 100vh;
        }

        header {
            padding: 38px 24px 24px;
            text-align: center;
            border-bottom: 1px solid var(--hairline);
        }

        header .marca {
            font-family: 'Fraunces', serif;
            font-size: 1.5rem;
            font-weight: 500;
            margin: 0;
        }

        header .linha {
            width: 50px;
            height: 2px;
            background: var(--brass);
            margin: 12px auto;
            border: none;
        }

        main {
            display: flex;
            justify-content: center;
            padding: 40px 20px 60px;
        }

        .caixa-pagamento {
            width: 100%;
            max-width: 550px;
            background: var(--surface);
            border: 1px solid var(--hairline);
            border-top: 3px solid var(--brass);
            padding: 35px 30px;
        }

        h2 {
            font-family: 'Fraunces', serif;
            font-weight: 500;
            font-size: 1.3rem;
            margin-top: 0;
            margin-bottom: 20px;
            color: var(--ivory);
        }

        .campo {
            display: flex;
            flex-direction: column;
            gap: 6px;
            margin-bottom: 20px;
        }

        label {
            font-size: 0.85rem;
            color: var(--muted);
        }

        select, input {
            background: var(--ink);
            border: 1px solid var(--hairline);
            color: var(--ivory);
            font-family: 'Work Sans', sans-serif;
            font-size: 0.95rem;
            padding: 12px;
            border-radius: 2px;
            outline: none;
        }

        select:focus, input:focus {
            border-color: var(--brass);
            box-shadow: 0 0 0 3px var(--brass-soft);
        }

        .detalhes-pagamento {
            background: var(--surface-raised);
            border: 1px dashed var(--hairline);
            padding: 20px;
            margin-bottom: 20px;
            display: none;
        }

        .detalhes-pagamento.ativo {
            display: block;
        }

        .acoes {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-top: 30px;
        }

        button {
            background: var(--brass);
            color: #1a1408;
            border: none;
            font-weight: 600;
            padding: 12px 24px;
            border-radius: 2px;
            cursor: pointer;
            transition: background 0.15s;
        }

        button:hover {
            background: #c39c68;
        }

        .voltar {
            color: var(--muted);
            text-decoration: none;
            font-size: 0.9rem;
        }

        .voltar:hover {
            color: var(--ivory);
        }
    </style>
</head>
<body>

    <header>
        <p class="marca">Quiet and Fast Luxury</p>
        <hr class="linha">
        <p style="color: var(--muted); font-size: 0.9rem; margin:0;">Finalização de Transação</p>
    </header>

    <main>
        <div class="caixa-pagamento">
            <h2>Escolha a Forma de Pagamento</h2>

            <% if (veiculoSelecionado == null) { %>
                <p style="color:#c0605a;">Veículo não encontrado ou já vendido. <a href="catalogo.jsp" style="color:#b08a55;">Voltar ao catálogo</a>.</p>
            <% } else { %>

            <p style="color: var(--muted); margin-top: -10px; margin-bottom: 25px;">
                <%= veiculoSelecionado.getMarca() %> <%= veiculoSelecionado.getModelo() %> —
                R$ <%= String.format("%,.2f", veiculoSelecionado.getPreco()) %>
            </p>

            <form action="ProcessarPagamentoServlet" method="post">
                <input type="hidden" name="placa" value="<%= veiculoSelecionado.getPlaca() %>">

                <div class="campo">
                    <label for="nome">Nome completo</label>
                    <input type="text" id="nome" name="nome" placeholder="Seu nome" required>
                </div>
                <div class="campo">
                    <label for="cpf">CPF</label>
                    <input type="text" id="cpf" name="cpf" placeholder="000.000.000-00" required>
                </div>
                <div class="campo">
                    <label for="telefone">Telefone</label>
                    <input type="text" id="telefone" name="telefone" placeholder="(00) 00000-0000" required>
                </div>
                <div class="campo">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" placeholder="voce@email.com" required>
                </div>
                <div class="campo">
                    <label for="endereco">Endereço</label>
                    <input type="text" id="endereco" name="endereco" placeholder="Rua, número, cidade" required>
                </div>

                <div class="campo">
                    <label for="metodo">Método de Pagamento</label>
                    <select id="metodo" name="metodo" required onchange="mostrarDetalhes(this.value)">
                        <option value="">Selecione...</option>
                        <option value="pix">Pix</option>
                        <option value="credito">Cartão de Crédito</option>
                        <option value="debito">Cartão de Débito</option>
                        <option value="dinheiro">Dinheiro (Presencial)</option>
                    </select>
                </div>

                <!-- Detalhes do Pix -->
                <div id="bloco-pix" class="detalhes-pagamento">
                    <p style="margin:0 0 10px 0; color: var(--brass);"><strong>Pagamento via Pix</strong></p>
                    <p style="font-size: 0.9rem; color: var(--muted); margin:0;">Um QR Code e a chave Pix copia e cola serão gerados após confirmar o pedido para conclusão instantânea.</p>
                </div>

                <!-- Detalhes do Cartão (Crédito / Débito) -->
                <div id="bloco-cartao" class="detalhes-pagamento">
                    <p style="margin:0 0 15px 0; color: var(--brass);"><strong>Dados do Cartão</strong></p>
                    <div class="campo" style="margin-bottom:12px;">
                        <label>Número do Cartão</label>
                        <input type="text" placeholder="0000 0000 0000 0000">
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <input type="text" placeholder="Validade (MM/AA)">
                        <input type="text" placeholder="CVV">
                    </div>
                    <div class="campo" style="margin-top:12px;">
                        <label>Parcelas</label>
                        <select name="parcelas">
                            <option value="1">1x</option>
                            <option value="2">2x</option>
                            <option value="3">3x</option>
                            <option value="6">6x</option>
                            <option value="12">12x</option>
                        </select>
                    </div>
                </div>

                <!-- Detalhes em Dinheiro -->
                <div id="bloco-dinheiro" class="detalhes-pagamento">
                    <p style="margin:0 0 10px 0; color: var(--brass);"><strong>Pagamento em Dinheiro</strong></p>
                    <p style="font-size: 0.9rem; color: var(--muted); margin:0;">O pagamento em espécie deverá ser efetivado diretamente na nossa concessionária física ao retirar o superdesportivo.</p>
                </div>

                <div class="acoes">
                    <button type="submit">Confirmar Pagamento</button>
                    <a href="catalogo.jsp" class="voltar">← Voltar ao Catálogo</a>
                </div>
            </form>
            <% } %>
        </div>
    </main>

    <script>
        function mostrarDetalhes(metodo) {
            // Esconde todos os blocos
            document.getElementById('bloco-pix').classList.remove('ativo');
            document.getElementById('bloco-cartao').classList.remove('ativo');
            document.getElementById('bloco-dinheiro').classList.remove('ativo');

            // Mostra o bloco correspondente
            if (metodo === 'pix') {
                document.getElementById('bloco-pix').classList.add('ativo');
            } else if (metodo === 'credito' || metodo === 'debito') {
                document.getElementById('bloco-cartao').classList.add('ativo');
            } else if (metodo === 'dinheiro') {
                document.getElementById('bloco-dinheiro').classList.add('ativo');
            }
        }
    </script>
</body>
</html>