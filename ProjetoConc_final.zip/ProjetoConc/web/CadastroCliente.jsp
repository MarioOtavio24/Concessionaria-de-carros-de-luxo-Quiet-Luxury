<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%@ page import="Model.Cliente" %>
<%@ page import="DAO.ClienteDAO" %>
<%@ page import="Model.Veiculo" %>
<%@ page import="DAO.VeiculoDAO" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Cadastro Concluído</title>
</head>
<body>

<%
    // Pega os dados enviados pelo formulário
    String nome = request.getParameter("nome");
    String cpf = request.getParameter("cpf");
    String telefone = request.getParameter("telefone");
    String email = request.getParameter("email");
    String endereco = request.getParameter("endereco");

    // Monta o objeto Cliente
    Cliente cliente = new Cliente();
    cliente.setNome(nome);
    cliente.setCpf(cpf);
    cliente.setTelefone(telefone);
    cliente.setEmail(email);
    cliente.setEndereco(endereco);

    // Salva no banco
    ClienteDAO clienteDAO = new ClienteDAO();
    clienteDAO.cadastrar(cliente);

    // Busca os veículos disponíveis pra mostrar no catálogo
    VeiculoDAO veiculoDAO = new VeiculoDAO();
    List<Veiculo> veiculosDisponiveis = veiculoDAO.listarTodos();
%>

<h1>Cadastro concluído!</h1>
<p>Bem-vindo(a), <%= nome %>! Seu cadastro foi realizado com sucesso.</p>

<hr>

<h2>Catálogo de veículos disponíveis</h2>

<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>Modelo</th>
        <th>Marca</th>
        <th>Ano</th>
        <th>Preço</th>
    </tr>
    <% for (Veiculo v : veiculosDisponiveis) { %>
        <tr>
            <td><%= v.getModelo() %></td>
            <td><%= v.getMarca() %></td>
            <td><%= v.getAno() %></td>
            <td>R$ <%= v.getPreco() %></td>
            <td> <%= v.getCategoria() %></td>
            <td><%= v.getCor() %></td> 
            <td> <%= v.getImagem() %></td> 
            
        </tr>
    <% } %>
</table>
           
<br>
<a href="index.html">Voltar à página inicial</a>

</body>
</html>