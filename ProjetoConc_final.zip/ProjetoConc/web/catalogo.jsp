<%@page import="java.util.List"%>
<%@page import="DAO.VeiculoDAO"%>
<%@page import="Model.Veiculo"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo de Luxo — Mario & Guilherme Luxury Cars</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Work+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --ink: #15151a;
            --surface: #1f1e24;
            --surface-raised: #262530;
            --brass: #b08a55;
            --brass-soft: rgba(176, 138, 85, 0.35);
            --ivory: #ede7da;
            --muted: #96907f;
            --hairline: #322f36;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background: var(--ink);
            color: var(--ivory);
            font-family: 'Work Sans', sans-serif;
            min-height: 100vh;
        }

        header {
            padding: 48px 24px 32px;
            text-align: center;
            border-bottom: 1px solid var(--hairline);
        }

        header .marca {
            font-family: 'Fraunces', serif;
            font-size: 1.75rem;
            font-weight: 500;
            margin: 0;
        }

        header .linha {
            width: 64px;
            height: 2px;
            background: var(--brass);
            margin: 18px auto;
            border: none;
        }

        header .subtitulo {
            color: var(--muted);
            font-size: 0.95rem;
            margin: 0;
        }

        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .topo-acoes {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .btn-novo {
            background: var(--brass);
            color: #1a1408;
            padding: 10px 20px;
            text-decoration: none;
            font-weight: 600;
            border-radius: 2px;
            transition: background 0.15s ease;
        }

        .btn-novo:hover {
            background: #c39c68;
        }

        .grid-carros {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 30px;
        }

        .card {
            background: var(--surface);
            border: 1px solid var(--hairline);
            border-top: 3px solid var(--brass);
            border-radius: 2px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-bottom: 1px solid var(--hairline);
        }

        .card-conteudo {
            padding: 24px;
            display: flex;
            flex-direction: column;
            gap: 12px;
            flex-grow: 1;
        }

        .card h3 {
            font-family: 'Fraunces', serif;
            font-size: 1.3rem;
            margin: 0;
            color: var(--ivory);
        }

        .card .detalhes {
            color: var(--muted);
            font-size: 0.9rem;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }

        .card .preco {
            font-family: 'Fraunces', serif;
            font-size: 1.25rem;
            color: var(--brass);
            margin-top: auto;
            padding-top: 16px;
            border-top: 1px solid var(--hairline);
        }

        .sem-veiculos {
            text-align: center;
            color: var(--muted);
            grid-column: 1 / -1;
            padding: 60px 0;
            font-size: 1.1rem;
        }
    </style>
</head>
<body>

    <header>
        <p class="marca">Quiet and Fast Luxury by Mario & Guilherme</p>
        <hr class="linha">
        <p class="subtitulo">Catálogo Exclusivo de Superdesportivos</p>
    </header>

    <div class="container">
        <div class="topo-acoes">
            <h2 style="font-family: 'Fraunces', serif; font-weight: 500; margin: 0;">Veículos Disponíveis</h2>
            <a href="/ProjetoConc/cadastrar_Veiculo.html" class="btn-novo">+ Registar Novo Veículo</a>
        </div>

        <div class="grid-carros">
            <%
                try {
                    VeiculoDAO dao = new VeiculoDAO();
                    List<Veiculo> lista = dao.listarTodos(); // Certifica-te que o método no DAO que busca todos se chama listar()
                    
                    if (lista != null && !lista.isEmpty()) {
                        for (Veiculo v : lista) {
            %>
                            <div class="card">
                                <% if (v.getImagem() != null && !v.getImagem().isEmpty()) { %>
                                    <img src="/imagens/<%= v.getImagem() %>" alt="<%= v.getModelo() %>">
                                <% } else { %>
                                    <img src="/ProjetoConc/default.jpg" alt="Sem imagem">
                                <% } %>
                                <div class="card-conteudo">
                                    <h3><%= v.getMarca() %> <%= v.getModelo() %></h3>
                                    <div class="detalhes">
                                        <span><strong>Ano:</strong> <%= v.getAno() %></span>
                                        <span><strong>Cor:</strong> <%= v.getCor() %></span>
                                        <span><strong>Placa:</strong> <%= v.getPlaca() %></span>
                                        <span><strong>Km:</strong> <%= v.getQuilometragem() %></span>
                                    </div>
                                    <div class="preco" style="display: flex; justify-content: space-between; align-items: center;">
    <span>R$ <%= String.format("%,.2f", v.getPreco()) %></span>
    <a href="pagamento.jsp?id=<%= v.getPlaca() %>" style="background: var(--brass); color: #1a1408; padding: 6px 14px; font-size: 0.85rem; text-decoration: none; font-weight: 600; border-radius: 2px;">Comprar</a>
                                   </div>
                                </div>
                            </div>
            <%
                        }
                    } else {
            %>
                        <div class="sem-veiculos">
                            Ainda não existem veículos registados no catálogo. Clica em "Registar Novo Veículo" para começar.
                        </div>
            <%
                    }
                } catch (Exception e) {
            %>
                    <div class="sem-veiculos" style="color: var(--error);">
                        Erro ao carregar o catálogo: <%= e.getMessage() %>
                    </div>
            <%
                }
            %>
        </div>
    </div>

</body>
</html>
