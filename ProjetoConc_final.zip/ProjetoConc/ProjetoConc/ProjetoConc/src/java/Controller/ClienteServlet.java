package Controller;

import DAO.ClienteDAO;
import Model.Cliente;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ClienteServlet", urlPatterns = {"/ClienteServlet"})
public class ClienteServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String nome = request.getParameter("nome");
        String cpf = request.getParameter("cpf");
        String telefone = request.getParameter("telefone");
        String email = request.getParameter("email");
        String endereco = request.getParameter("endereco");

        if (nome == null || nome.isBlank()
                || cpf == null || cpf.isBlank()
                || telefone == null || telefone.isBlank()
                || email == null || email.isBlank()
                || endereco == null || endereco.isBlank()) {

            exibirResultado(response, false,
                    "Não foi possível cadastrar: todos os campos são obrigatórios.");
            return;
        }

        try {
            Cliente cliente = new Cliente();
            cliente.setNome(nome);
            cliente.setCpf(cpf);
            cliente.setTelefone(telefone);
            cliente.setemail(email);
            cliente.setendereco(endereco);

            ClienteDAO clienteDAO = new ClienteDAO();
            clienteDAO.cadastrar(cliente);

            exibirResultado(response, true,
                    "Cliente " + nome + " cadastrado com sucesso.");

        } catch (Exception e) {
            e.printStackTrace();
            exibirResultado(response, false,
                    "Erro ao cadastrar cliente: " + e.getMessage());
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("index.html");
    }

    private void exibirResultado(HttpServletResponse response, boolean sucesso, String mensagem)
            throws IOException {

        String corDestaque = sucesso ? "#b08a55" : "#c0605a";
        String titulo = sucesso ? "Cadastro realizado" : "Não foi possível cadastrar";

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html lang=\"pt-BR\">");
            out.println("<head>");
            out.println("<meta charset=\"UTF-8\">");
            out.println("<title>" + titulo + " — Concessionária</title>");
            out.println("<style>");
            out.println("body{margin:0;background:#15151a;color:#ede7da;font-family:sans-serif;");
            out.println("display:flex;align-items:center;justify-content:center;min-height:100vh;}");
            out.println(".caixa{max-width:480px;padding:40px;border:1px solid #322f36;");
            out.println("border-top:3px solid " + corDestaque + ";background:#1f1e24;text-align:center;}");
            out.println("h1{font-size:1.3rem;margin:0 0 12px;}");
            out.println("p{color:#96907f;margin:0 0 28px;}");
            out.println("a{color:#1a1408;background:" + corDestaque + ";text-decoration:none;");
            out.println("padding:12px 24px;font-weight:600;display:inline-block;}");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class=\"caixa\">");
            out.println("<h1>" + titulo + "</h1>");
            out.println("<p>" + mensagem + "</p>");
            out.println("<a href=\"index.html\">Voltar ao cadastro</a>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}