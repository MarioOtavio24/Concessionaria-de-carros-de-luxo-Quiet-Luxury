
package Controller;

import DAO.ConexaoBD;
import java.sql.Connection;

public class BancoTeste {
    
   public static void main(String [] args){
       Connection c = ConexaoBD.getConnection();
       if ( c!= null){
           System.out.println("Conectou ao banco com sucesso!");
       }else{
            System.out.println ("Falha na Conexao. ");
       }
        ConexaoBD.fecharConexao();
       }
   }

