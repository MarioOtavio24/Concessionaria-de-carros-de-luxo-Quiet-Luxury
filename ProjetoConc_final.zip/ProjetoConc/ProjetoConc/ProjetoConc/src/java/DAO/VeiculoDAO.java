/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Model.Veiculo;

public class VeiculoDAO {

    public void cadastrar(Veiculo veiculo) {
        String sql = "INSERT INTO veiculo (placa, marca, modelo, ano, cor, preco, quilometragem, categoria) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, veiculo.getPlaca());
            stmt.setString(2, veiculo.getMarca());
            stmt.setString(3, veiculo.getModelo());
            stmt.setInt(4, veiculo.getAno());
            stmt.setString(5, veiculo.getCor());
            stmt.setDouble(6, veiculo.getPreco());
            stmt.setDouble(7, veiculo.getQuilometragem());
            stmt.setString(8, veiculo.getCategoria());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Veiculo consultar(int idVeiculo) {
        String sql = "SELECT * FROM veiculo WHERE idVeiculo = ?";
        Veiculo veiculo = null;

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idVeiculo);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    veiculo = montarVeiculo(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return veiculo;
    }

    public List<Veiculo> listarTodos() {
        String sql = "SELECT * FROM veiculo";
        List<Veiculo> veiculos = new ArrayList<>();

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                veiculos.add(montarVeiculo(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return veiculos;
    }

    public void atualizar(Veiculo veiculo) {
        String sql = "UPDATE veiculo SET placa = ?, marca = ?, modelo = ?, ano = ?, cor = ?, "
                + "preco = ?, quilometragem = ?, categoria = ? WHERE idVeiculo = ?";

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, veiculo.getPlaca());
            stmt.setString(2, veiculo.getMarca());
            stmt.setString(3, veiculo.getModelo());
            stmt.setInt(4, veiculo.getAno());
            stmt.setString(5, veiculo.getCor());
            stmt.setDouble(6, veiculo.getPreco());
            stmt.setDouble(7, veiculo.getQuilometragem());
            stmt.setString(8, veiculo.getCategoria());
            stmt.setInt(9, veiculo.getIdVeiculo());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletar(int idVeiculo) {
        String sql = "DELETE FROM veiculo WHERE idVeiculo = ?";

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idVeiculo);
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método auxiliar para não repetir a montagem do objeto em consultar() e listarTodos()
    private Veiculo montarVeiculo(ResultSet rs) throws SQLException {
        Veiculo veiculo = new Veiculo();
        veiculo.setIdVeiculo(rs.getInt("idVeiculo"));
        veiculo.setPlaca(rs.getString("placa"));
        veiculo.setMarca(rs.getString("marca"));
        veiculo.setModelo(rs.getString("modelo"));
        veiculo.setAno(rs.getInt("ano"));
        veiculo.setCor(rs.getString("cor"));
        veiculo.setPreco(rs.getDouble("preco"));
        veiculo.setQuilometragem(rs.getDouble("quilometragem"));
        veiculo.setCategoria(rs.getString("categoria"));
        return veiculo;
    }
}