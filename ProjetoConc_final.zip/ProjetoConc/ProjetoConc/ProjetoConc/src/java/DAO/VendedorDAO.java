/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Model.Vendedor;

public class VendedorDAO {

    public void cadastrar(Vendedor vendedor) {
        String sql = "INSERT INTO vendedor (nome, cpf, telefone, email, comissao) VALUES (?, ?, ?, ?, ?)";

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, vendedor.getNome());
            stmt.setString(2, vendedor.getCpf());
            stmt.setString(3, vendedor.getTelefone());
            stmt.setString(4, vendedor.getEmail());
            stmt.setDouble(5, vendedor.getComissão());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Vendedor consultar(int idVendedor) {
        String sql = "SELECT * FROM vendedor WHERE idVendedor = ?";
        Vendedor vendedor = null;

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idVendedor);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    vendedor = montarVendedor(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vendedor;
    }

    public List<Vendedor> listarTodos() {
        String sql = "SELECT * FROM vendedor";
        List<Vendedor> vendedores = new ArrayList<>();

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                vendedores.add(montarVendedor(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vendedores;
    }

    public void atualizar(Vendedor vendedor) {
        String sql = "UPDATE vendedor SET nome = ?, cpf = ?, telefone = ?, email = ?, comissao = ? WHERE idVendedor = ?";

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, vendedor.getNome());
            stmt.setString(2, vendedor.getCpf());
            stmt.setString(3, vendedor.getTelefone());
            stmt.setString(4, vendedor.getEmail());
            stmt.setDouble(5, vendedor.getComissão());
            stmt.setInt(6, vendedor.getIdVendedor());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletar(int idVendedor) {
        String sql = "DELETE FROM vendedor WHERE idVendedor = ?";

        try (Connection conexao = ConexaoBD.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idVendedor);
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método auxiliar para não repetir a montagem do objeto em consultar() e listarTodos()
    private Vendedor montarVendedor(ResultSet rs) throws SQLException {
        Vendedor vendedor = new Vendedor();
        vendedor.setIdVendedor(rs.getInt("idVendedor"));
        vendedor.setNome(rs.getString("nome"));
        vendedor.setCpf(rs.getString("cpf"));
        vendedor.setTelefone(rs.getString("telefone"));
        vendedor.setEmail(rs.getString("email"));
        vendedor.setComissão(rs.getDouble("comissao"));
        return vendedor;
    }
}